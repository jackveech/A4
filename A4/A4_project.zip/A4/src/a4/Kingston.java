package a4;

public class Kingston {

	public static void main(String... args) {
		StringSet set = A4.fromList(A4.readFile("kingston.txt"));
		
		
	}
}
